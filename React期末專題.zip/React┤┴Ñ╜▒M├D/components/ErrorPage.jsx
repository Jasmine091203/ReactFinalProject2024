import MainNavLink from "./MainNavLink";
const ErrorPage = () => {
    return (
        <div>
            <MainNavLink />
            <hr />
            <h1>錯誤發生！無法找到此頁面</h1>
        </div>
    );
}

export default ErrorPage;